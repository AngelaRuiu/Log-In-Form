function showFormElements(oForm) {
   var cnt = 0;
   var msg = "Form with 'name' attribute='" + oForm.name + "'";
   var str = "\nThe elements are: \n\n";
   for (i = 0; i < oForm.length; i++) {
	cnt ++; 
	str += oForm.elements[i].tagName + " with 'name' attribute='" + oForm.elements[i].name + "'\n";
   }

   msg += " has " + cnt + " elements. \n" + str;
   alert(msg);
}

function showFormData(oForm) {
   var msg = "The data that you entered for the form with 'name' attribute='" + oForm.name + "': \n";
   
   for (i = 0; i < oForm.length, oForm.elements[i].getAttribute("type") !== 'button'; i++) {
	   msg += oForm.elements[i].tagName + " with 'name' attribute='" + oForm.elements[i].name + "' and data: ";
	   if(oForm.elements[i].value == null || oForm.elements[i].value == '') {
		msg += "NOT SET \n";
	   } else {
		   msg += oForm.elements[i].value + "\n";
	   }
   }

   alert(msg);
}


function copyFormElementToElementOfDifferentForm(oForm1Name, oForm2Name, oForm1ElementName, oForm2ElementName) {

	var oForm1 = document.forms[oForm1Name];
	var oForm2 = document.forms[oForm2Name];
	var oForm1Element = oForm1[oForm1ElementName];
	var oForm2Element = oForm2[oForm2ElementName];

	if(oForm2Element.value == '') {
		oForm2Element.value += oForm1Element.value;
	} else {
		oForm2Element.value += ', ' + oForm1Element.value;
	}
}
