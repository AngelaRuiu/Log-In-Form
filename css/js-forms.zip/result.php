<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Demo - Result</title>
<link rel="stylesheet" href="css/ex.css" type="text/css" />
<style type="text/css">

</style>
</head>
<body>
    
<h1>Posted Data</h1>

<p>Outputting posted data from the demo form:</p>

<?php
echo "<pre>";
print_r($_POST);
echo "\n</pre>";
?>

<p>This tutorial focuses on JavaScript and forms, but perhaps some server-side handling will be added at a later date. <a href="http://www.dyn-web.com/tutorials/forms/">Check back</a> for updates.</p>

<p>Back to <a href="index.html">index</a> for more demos and information.</p>

</body>
</html>